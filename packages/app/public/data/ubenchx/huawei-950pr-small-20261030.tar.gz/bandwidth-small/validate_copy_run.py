"""Reject incomplete/mismatched rotating-copy captures before queue advancement."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path

from copy_rotating_small_cann921 import SIZES, plan


def validate(folder, pilot=False, process=0, small=False):
    meta=json.loads((folder/'metadata.json').read_text())
    script=Path(__file__).with_name('copy_rotating_small_cann921.py')
    assert not (pilot and small)
    sizes=[8,4096,1048576] if pilot else ([2**k for k in range(3,13)]+[16384] if small else SIZES)
    blocks,reps=(1,3) if pilot else (6,20)
    assert meta['complete'] and not meta['foreign_or_monitor_failures']
    assert meta['protocol']=='copy_only_rotating_pools_graph_v2_strided_small'
    assert meta['script_sha256']==hashlib.sha256(script.read_bytes()).hexdigest()
    assert meta['graph'] and meta['process']==process and meta['minimum_bytes_per_pool']==512*2**20
    assert sorted(meta['sizes'])==sorted(sizes)
    assert (meta['blocks'],meta['samples_per_block'])==(blocks,reps)
    with (folder/'timings.csv').open() as f:rows=list(csv.DictReader(f))
    with (folder/'sweeps.csv').open() as f:sweeps=list(csv.DictReader(f))
    assert len(rows)==meta['total_samples']==len(sizes)*blocks*reps
    assert len(sweeps)==meta['total_sweeps']==len(sizes)*blocks
    assert Counter(int(r['size_bytes']) for r in rows)==Counter({s:blocks*reps for s in sizes})
    keys=set()
    for r in rows:
        size=int(r['size_bytes']);cfg=plan(size,512)
        key=(size,int(r['block']),int(r['sample']))
        assert key not in keys and 0<=key[1]<blocks and 0<=key[2]<reps
        keys.add(key)
        assert int(r['process'])==process
        for name in ('slots','slot_stride_bytes','active_pool_bytes'):assert int(r[name])==cfg[name]
        interval=float(r['interval_ms']);latency=float(r['latency_ms']);bw=float(r['effective_GBps'])
        assert math.isfinite(interval) and interval>0
        assert int(r['timed_copies'])==cfg['slots']
        assert math.isclose(latency,interval/cfg['slots'],rel_tol=1e-10)
        assert math.isclose(bw,2*size/(latency*1e6),rel_tol=1e-10)
        assert math.isclose(float(r['mbu_percent']),bw/16,rel_tol=1e-10)
    expected_checked=sum(plan(s,512)['pool_bytes'] for s in sizes)*blocks
    assert meta['full_checked_destination_bytes']==meta['graph_prechecked_destination_bytes']==expected_checked
    sweep_keys=set()
    for r in sweeps:
        size=int(r['size_bytes']);cfg=plan(size,512);key=(size,int(r['block']))
        assert size in sizes and 0<=key[1]<blocks and key not in sweep_keys
        sweep_keys.add(key)
        assert int(r['process'])==process
        assert int(r['copies'])==cfg['slots']*reps
        assert int(r['full_checked_bytes'])==cfg['pool_bytes']
        assert 0<float(r['sum_sample_ms'])<=float(r['event_ms'])<=float(r['wall_ms'])*1.02
        assert math.isclose(float(r['batch_GBps']),2*size*cfg['slots']*reps/(float(r['event_ms'])*1e6),rel_tol=1e-10)
    return {'accepted':True,'sizes':len(sizes),'samples':len(rows),'process':process,'pilot':pilot}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('--pilot',action='store_true');p.add_argument('--process',type=int,default=0);p.add_argument('--small',action='store_true')
    a=p.parse_args();print(json.dumps(validate(a.folder,a.pilot,a.process,a.small)))
