"""Copy-only rotating FP16 graph sweep, extended to 8-byte messages.

For sizes below 4 KiB, use 4 KiB slot pitch and cap graph copies at 131072.
Allocated address span remains >=512 MiB per pool; touched bytes are smaller.
This measures small-copy throughput, not proof of cold HBM traffic.
For sizes >=4 KiB the original contiguous-slot protocol is retained.
"""
from pathlib import Path
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import os
import random
import re
import subprocess
import threading
import time

MIB=2**20
SIZES=[2**k for k in range(3,20)]+[m*MIB for m in (1,2,3,4,6,8,10,12,14,16,20,24,28,32,40,48,56,64,80,96,112,128,160,192,224,256,384,512,768)]+[g*2**30 for g in (1,2,4,8,16)]

def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def save(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def smi():
    r=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=12)
    if r.returncode:raise RuntimeError(r.stderr)
    return r.stdout
def pids(text):return set(map(int,re.findall(r'^\|\s*0\s*\|\s*(\d+)\s*\|',text,re.M)))
def idle_util(text):
    # The row below the product row contains bus-id, utilization and memory.
    rows=[s for s in text.splitlines() if re.search(r'\d{4}:[0-9A-Fa-f]{2}:',s)]
    assert len(rows)==1,rows
    cells=rows[0].split('|')
    bus=next(i for i,c in enumerate(cells) if re.search(r'\d{4}:[0-9A-Fa-f]{2}:',c))
    return int(cells[bus+1].split()[0])
def plan(size,pool_mib):
    stride=max(size,4096)
    slots=max(2,math.ceil(pool_mib*MIB/stride))
    return {'size_bytes':size,'slots':slots,'slot_stride_bytes':stride,'active_pool_bytes':slots*size,'pool_bytes':slots*stride,'combined_pool_bytes':2*slots*stride}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',required=True)
    ap.add_argument('--process',type=int,default=0)
    ap.add_argument('--blocks',type=int,default=6)
    ap.add_argument('--reps',type=int,default=20)
    ap.add_argument('--pool-mib',type=int,default=512)
    ap.add_argument('--sizes')
    ap.add_argument('--plan-only',action='store_true')
    ap.add_argument('--graph',action='store_true',help='Time replay of a complete copy-only ring to avoid Python submission gaps')
    a=ap.parse_args();sizes=SIZES if not a.sizes else list(map(int,a.sizes.split(',')))
    assert len(sizes)==len(set(sizes)) and all(s>=8 and s%2==0 for s in sizes)
    assert a.pool_mib>=512 and a.blocks>0 and a.reps>=2
    if a.plan_only:
        print(json.dumps([plan(s,a.pool_mib) for s in sizes],indent=2));return
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
    checks=[]
    # Three idle snapshots before importing the device stack or allocating.
    for i in range(3):
        status=smi();checks.append({'utc':now(),'smi':status})
        save(out/'idle-before.json',checks)
        assert not pids(status) and idle_util(status)==0, 'NPU is not idle; no benchmark started'
        if i<2:time.sleep(2)
    import numpy as np
    import torch
    import torch_npu
    torch.set_num_threads(1);torch.npu.set_device(0)
    owner=os.getpid();stop=threading.Event();bad=[]
    def watch():
        while not stop.is_set():
            try:
                text=smi();foreign=sorted(pids(text)-{owner})
                r={'utc':now(),'owner_pid':owner,'foreign_pids':foreign,'smi':text}
                with (out/'monitor.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
                if foreign:bad.append(r)
            except Exception as e:bad.append({'utc':now(),'monitor_error':repr(e)})
            stop.wait(2)
    thread=threading.Thread(target=watch,daemon=True);thread.start()
    def guard():assert not bad,('External activity or monitoring failure; entire process rejected',bad)
    meta={'protocol':'copy_only_rotating_pools_graph_v2_strided_small' if a.graph else 'copy_only_rotating_pools_v1','graph':a.graph,'utc_start':now(),'process':a.process,'pid':owner,
          'torch':torch.__version__,'torch_npu':torch_npu.__version__,
          'device':str(torch.npu.get_device_properties(0)),'sizes':sizes,
          'blocks':a.blocks,'samples_per_block':a.reps,'minimum_bytes_per_pool':a.pool_mib*MIB,
          'minimum_slots':2,'small_message_slot_pitch_bytes':4096,'small_message_active_bytes_can_fit_cache':True,'allocated_span_is_not_cache_miss_proof':True,'warmup_complete_rotations_per_block':2,
          'graph_validation':'After warmup, poison destination and replay once; compare every active byte and verify all padding remains poisoned. Three complete graph warmups then precede timing.' if a.graph else None,
          'measured_sweep':f'graph mode: slots copies per replay, {a.reps} event-timed replays per block',
          'timing':(f'{a.reps} complete ring graph replays timed with device events; per-copy latency is replay latency divided by ring slots' if a.graph else f'{a.reps} evenly distributed individual device-event copy intervals per sweep, plus whole-sweep device events and synchronized host wall time'),
          'small_copy_limit':'Individual events can include host submission gaps; full-sweep rate exposes host/launch throughput limits. These are effective copy rates, not hardware-counter HBM traffic.',
          'dtype':'float16','traffic_multiplier':2,'nominal_GBps':1600,
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cann_environment':os.environ.get('ASCEND_HOME_PATH'),'complete':False}
    save(out/'metadata.json',meta)
    checked=0;prechecked=0;samples_total=0;sweeps_total=0
    rng=random.Random(2026100700+a.process);rng.shuffle(sizes)
    meta['sizes']=sizes;save(out/'metadata.json',meta)
    try:
        starts=[torch.npu.Event(enable_timing=True) for _ in range(a.reps)]
        ends=[torch.npu.Event(enable_timing=True) for _ in range(a.reps)]
        sweep_start=torch.npu.Event(enable_timing=True);sweep_end=torch.npu.Event(enable_timing=True)
        for event in starts+ends+[sweep_start,sweep_end]:event.record()
        torch.npu.synchronize()
        def validate(src,dst):
            x=src.view(torch.int16);y=dst.view(torch.int16)
            if cfg['slot_stride_bytes']==size:
                for begin in range(0,len(x),32*MIB):
                    assert torch.equal(x[begin:begin+32*MIB],y[begin:begin+32*MIB]),('copy mismatch',begin)
            else:
                xx=x.reshape(slots,stride_elements);yy=y.reshape(slots,stride_elements)
                row_chunk=max(1,32*MIB//stride_elements)
                for begin in range(0,slots,row_chunk):
                    assert torch.equal(xx[begin:begin+row_chunk,:elements],yy[begin:begin+row_chunk,:elements]),('active copy mismatch',begin)
                    assert bool((yy[begin:begin+row_chunk,elements:]==32767).all()),('padding overwritten',begin)
            return src.numel()*2
        with (out/'timings.csv').open('w',newline='') as tf,(out/'sweeps.csv').open('w',newline='') as bf:
            tw=csv.DictWriter(tf,fieldnames=['process','size_bytes','slots','slot_stride_bytes','active_pool_bytes','block','sample','copy_index','slot','offset_bytes','latency_ms','effective_GBps','mbu_percent','timed_copies','interval_ms'])
            bw=csv.DictWriter(bf,fieldnames=['process','size_bytes','slots','slot_stride_bytes','active_pool_bytes','combined_pool_bytes','block','copies','start_slot','event_ms','wall_ms','batch_GBps','sum_sample_ms','full_checked_bytes','pattern_sha256','src_ptr','dst_ptr'])
            tw.writeheader();bw.writeheader()
            for size in sizes:
                guard();cfg=plan(size,a.pool_mib);slots=cfg['slots'];elements=size//2;stride_elements=cfg['slot_stride_bytes']//2
                free,total=torch.npu.mem_get_info();assert cfg['combined_pool_bytes']+2*2**30<=min(96*2**30,free-8*2**30),'copy pool exceeds memory budget'
                src=torch.empty(cfg['pool_bytes']//2,dtype=torch.float16,device='npu');dst=torch.empty_like(src)
                assert src.data_ptr()+cfg['pool_bytes']<=dst.data_ptr() or dst.data_ptr()+cfg['pool_bytes']<=src.data_ptr()
                views=[(src.narrow(0,i*stride_elements,elements),dst.narrow(0,i*stride_elements,elements)) for i in range(slots)]
                graph=None
                cursor=0
                for block in range(a.blocks):
                    guard()
                    seed=2026100700+a.process*1000003+size//4096+block*1009
                    prng=np.random.default_rng(seed)
                    length=min(65536,len(src));assert len(src)%length==0
                    bits=prng.integers(0,65536,size=length,dtype=np.uint16)
                    bits[(bits&0x7c00)==0x7c00]^=np.uint16(0x0400)
                    tile=torch.from_numpy(bits.view(np.int16).copy()).npu()
                    src.view(torch.int16).view(-1,length).copy_(tile,non_blocking=True)
                    # Three per-slot tags catch wrong source/destination slot selection.
                    indices=(np.arange(slots,dtype=np.int64)[:,None]*stride_elements+np.array([0,elements//2,elements-1])).reshape(-1)
                    tags=prng.integers(0,16384,size=len(indices),dtype=np.int16)
                    src.view(torch.int16)[torch.from_numpy(indices).npu()]=torch.from_numpy(tags).npu()
                    dst.view(torch.int16).fill_(32767)
                    torch.npu.synchronize()
                    # Initialization, poison and validation never occur between measured copies.
                    for _ in range(2):
                        for i in range(slots):
                            sv,dv=views[(cursor+i)%slots];dv.copy_(sv,non_blocking=True)
                        torch.npu.synchronize();guard()
                    if a.graph:
                        if graph is None:
                            graph=torch.npu.NPUGraph()
                            with torch.npu.graph(graph):
                                for sv,dv in views:dv.copy_(sv,non_blocking=True)
                            torch.npu.synchronize()
                        dst.view(torch.int16).fill_(32767)
                        torch.npu.synchronize();graph.replay();torch.npu.synchronize()
                        prechecked+=validate(src,dst)
                        for _ in range(3):graph.replay()
                        torch.npu.synchronize();guard()
                        begin=time.perf_counter();sweep_start.record()
                        for i in range(a.reps):
                            starts[i].record();graph.replay();ends[i].record()
                        sweep_end.record();torch.npu.synchronize()
                        wall_ms=(time.perf_counter()-begin)*1000;event_ms=float(sweep_start.elapsed_time(sweep_end))
                        intervals=[float(s.elapsed_time(e)) for s,e in zip(starts,ends)]
                        assert all(math.isfinite(t) and t>0 for t in intervals)
                        assert 0<sum(intervals)<=event_ms<=wall_ms*1.02,(intervals,event_ms,wall_ms)
                        guard();verified=validate(src,dst);checked+=verified
                        for j,t in enumerate(intervals):
                            rate=2*size*slots/(t*1e6)
                            tw.writerow(dict(process=a.process,size_bytes=size,slots=slots,slot_stride_bytes=cfg["slot_stride_bytes"],active_pool_bytes=cfg["active_pool_bytes"],block=block,sample=j,
                                             copy_index=0,slot=0,offset_bytes=0,latency_ms=t/slots,
                                             effective_GBps=rate,mbu_percent=rate/16,timed_copies=slots,interval_ms=t))
                        bw.writerow(dict(process=a.process,size_bytes=size,slots=slots,slot_stride_bytes=cfg["slot_stride_bytes"],active_pool_bytes=cfg["active_pool_bytes"],combined_pool_bytes=cfg['combined_pool_bytes'],block=block,copies=slots*a.reps,start_slot=0,event_ms=event_ms,wall_ms=wall_ms,batch_GBps=2*size*slots*a.reps/(event_ms*1e6),sum_sample_ms=sum(intervals),full_checked_bytes=verified,pattern_sha256=hashlib.sha256(bits.tobytes()+tags.tobytes()).hexdigest(),src_ptr=src.data_ptr(),dst_ptr=dst.data_ptr()))
                        tf.flush();bf.flush();samples_total+=a.reps;sweeps_total+=1
                        continue
                    n=max(slots,a.reps)
                    picks=((np.arange(a.reps)+.5)*n/a.reps).astype(np.int64)
                    assert len(np.unique(picks))==a.reps
                    selected={int(v):j for j,v in enumerate(picks)}
                    begin=time.perf_counter();sweep_start.record()
                    for i in range(n):
                        sv,dv=views[(cursor+i)%slots]
                        if i in selected:starts[selected[i]].record()
                        dv.copy_(sv,non_blocking=True)
                        if i in selected:ends[selected[i]].record()
                    sweep_end.record();torch.npu.synchronize()
                    wall_ms=(time.perf_counter()-begin)*1000;event_ms=float(sweep_start.elapsed_time(sweep_end))
                    times=[float(s.elapsed_time(e)) for s,e in zip(starts,ends)]
                    assert all(math.isfinite(t) and t>0 for t in times)
                    assert 0<sum(times)<=event_ms<=wall_ms*1.02,(times,event_ms,wall_ms)
                    guard();verified=validate(src,dst);checked+=verified
                    for j,(i,t) in enumerate(zip(picks,times)):
                        slot=(cursor+int(i))%slots;rate=2*size/(t*1e6)
                        tw.writerow(dict(process=a.process,size_bytes=size,slots=slots,slot_stride_bytes=cfg["slot_stride_bytes"],active_pool_bytes=cfg["active_pool_bytes"],block=block,sample=j,
                                         copy_index=int(i),slot=slot,offset_bytes=slot*cfg["slot_stride_bytes"],latency_ms=t,
                                         effective_GBps=rate,mbu_percent=rate/16,timed_copies=1,interval_ms=t))
                    bw.writerow(dict(process=a.process,size_bytes=size,slots=slots,slot_stride_bytes=cfg["slot_stride_bytes"],active_pool_bytes=cfg["active_pool_bytes"],combined_pool_bytes=cfg['combined_pool_bytes'],block=block,copies=n,start_slot=cursor,event_ms=event_ms,wall_ms=wall_ms,batch_GBps=2*size*n/(event_ms*1e6),sum_sample_ms=sum(times),full_checked_bytes=verified,pattern_sha256=hashlib.sha256(bits.tobytes()+tags.tobytes()).hexdigest(),src_ptr=src.data_ptr(),dst_ptr=dst.data_ptr()))
                    tf.flush();bf.flush();samples_total+=a.reps;sweeps_total+=1;cursor=(cursor+n)%slots
                print(json.dumps({'utc':now(),'size_bytes':size,**cfg,'validated':True,'samples':a.blocks*a.reps}),flush=True)
                if graph is not None:graph.reset()
                del graph,views,src,dst,tile;torch.npu.empty_cache()
        guard();meta.update(complete=True,total_samples=samples_total,total_sweeps=sweeps_total,full_checked_destination_bytes=checked,graph_prechecked_destination_bytes=prechecked)
    except BaseException as e:
        meta['error']=repr(e);raise
    finally:
        stop.set();thread.join(timeout=15)
        if bad:meta['complete']=False
        meta.update(utc_end=now(),foreign_or_monitor_failures=bad,smi_after=smi())
        save(out/'metadata.json',meta)
    print(json.dumps({'complete':meta['complete'],'samples':samples_total,'sweeps':sweeps_total}),flush=True)

if __name__=='__main__':main()
