#!/usr/bin/env bash
set -eo pipefail
source /root/bench/flash-campaign/env-cann921.sh
set -u
cd /root/bench/resume-20261030/bandwidth-small
exec 9>/root/bench/npu0-benchmark.lock
flock -n 9
exec >>queue.log 2>&1
trap 'code=$?; echo "$(date -u +%FT%TZ) exit=$code" >>status.txt' EXIT
echo "$(date -u +%FT%TZ) starting" >>status.txt
python3 copy_rotating_small_cann921.py --out pilot --graph --sizes 8,4096,1048576 --blocks 1 --reps 3
python3 validate_copy_run.py pilot --pilot
for process in 0 1 2; do
 python3 copy_rotating_small_cann921.py --out process-$process --graph --sizes 8,16,32,64,128,256,512,1024,2048,4096,16384 --blocks 6 --reps 20 --process "$process"
 python3 validate_copy_run.py process-$process --small --process "$process"
done
echo "$(date -u +%FT%TZ) complete" >>status.txt
